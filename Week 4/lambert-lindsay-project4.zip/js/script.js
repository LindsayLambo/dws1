var loginForm = document.getElementById('loginForm');
element.onevent = function;
loginForm.onsubmit = validateForm;